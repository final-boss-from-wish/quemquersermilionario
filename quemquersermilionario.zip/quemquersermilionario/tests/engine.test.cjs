const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { Game, PRIZES } = require('../engine.js');
const context = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../questions.js'), 'utf8'), context);
const data = JSON.parse(JSON.stringify(context.window.MILLIONAIRE_DATA));
function game(rng = Math.random) { return new Game(data.banks, rng); }
function winQuestion(g) { assert.equal(g.select(g.question.correct), true); assert.equal(g.confirm(), true); }

test('all 15 supplied databases are loaded and every playable row is complete', () => {
  const expected = [964,914,937,979,1044,985,1100,897,839,759,534,544,543,464,370];
  assert.equal(data.meta.total, 11873);
  assert.equal(data.meta.normalizedKeys, 3);
  assert.equal(data.meta.skipped.length, 1);
  assert.equal(data.meta.skipped[0].level, 15);
  for (let level = 1; level <= 15; level++) {
    assert.equal(data.banks[level].length, expected[level - 1]);
    for (const q of data.banks[level]) {
      assert.equal(q.level, level);
      assert.ok(q.text.trim());
      assert.equal(q.options.length, 4);
      assert.ok(q.options.every(a => typeof a === 'string' && a.trim()));
      assert.ok(Number.isInteger(q.correct) && q.correct >= 0 && q.correct <= 3);
    }
  }
});

test('each round draws from precisely its corresponding CSV', () => {
  for (let run = 0; run < 100; run++) {
    const g = game();
    assert.equal(g.questions.length, 15);
    g.questions.forEach((q, i) => {
      assert.equal(q.level, i + 1);
      assert.ok(data.banks[i + 1].includes(q));
    });
  }
});

test('a full run pays one million after exactly 15 confirmed correct answers', () => {
  const g = game();
  for (let i = 0; i < 15; i++) {
    assert.equal(g.index, i);
    winQuestion(g);
    assert.equal(g.earned, PRIZES[i]);
    assert.equal(g.confirm(), false);
    if (i < 14) assert.equal(g.next(), true);
  }
  assert.equal(g.phase, 'won');
  assert.equal(g.payout, 1000000);
  assert.equal(g.next(), false);
  assert.equal(g.walkAway(), false);
  assert.equal(g.select(0), false);
});

test('wrong answers on every level pay only previously secured safety nets', () => {
  for (let failAt = 0; failAt < 15; failAt++) {
    const g = game();
    for (let i = 0; i < failAt; i++) { winQuestion(g); g.next(); }
    g.select((g.question.correct + 1) % 4);
    assert.equal(g.confirm(), true);
    assert.equal(g.phase, 'lost');
    assert.equal(g.payout, failAt < 5 ? 0 : failAt < 10 ? 1000 : 32000);
    assert.equal(g.next(), false);
    assert.equal(g.confirm(), false);
    assert.equal(g.walkAway(), false);
    assert.equal(g.lifeline('fifty'), null);
  }
});

test('walk away keeps earned money before and after every non-final question', () => {
  for (let answered = 0; answered < 15; answered++) {
    for (const advance of [true, false]) {
      const g = game();
      for (let i = 0; i < answered; i++) { winQuestion(g); if (advance || i < answered - 1) g.next(); }
      assert.equal(g.walkAway(), true);
      assert.equal(g.phase, 'walked');
      assert.equal(g.payout, answered ? PRIZES[answered - 1] : 0);
      assert.equal(g.confirm(), false);
    }
  }
});

test('selection can be changed; invalid and unselected answers cannot be committed', () => {
  const g = game();
  assert.equal(g.confirm(), false);
  assert.equal(g.next(), false);
  for (const bad of [-1,4,0.5,null,undefined,'A']) assert.equal(g.select(bad), false);
  g.select((g.question.correct + 1) % 4);
  g.select(g.question.correct);
  assert.equal(g.confirm(), true);
  assert.equal(g.phase, 'correct');
});

test('50:50 always removes exactly two wrong answers and clears a removed selection', () => {
  for (let run = 0; run < 100; run++) {
    const g = game(() => 0);
    const wrong = [0,1,2,3].filter(i => i !== g.question.correct);
    g.select(wrong[2]);
    assert.deepEqual(g.lifeline('fifty'), { type:'fifty' });
    assert.equal(new Set(g.hidden).size, 2);
    assert.ok(!g.hidden.includes(g.question.correct));
    assert.equal(g.selected, null);
    for (const i of g.hidden) assert.equal(g.select(i), false);
    assert.equal(g.lifeline('fifty'), null);
    winQuestion(g); g.next();
    assert.equal(g.hidden.length, 0);
    assert.equal(g.used.fifty, true);
    assert.equal(g.lifeline('fifty'), null);
  }
});

test('simulated helpers respect 50:50, total exactly 100 votes, and can be wrong', () => {
  for (let run = 0; run < 200; run++) {
    const g = game();
    if (run % 2) g.lifeline('fifty');
    const poll = g.lifeline('audience');
    assert.equal(poll.votes.reduce((a,b) => a+b,0),100);
    g.hidden.forEach(i => assert.equal(poll.votes[i],0));
    const friend = g.lifeline('friend');
    assert.ok(!g.hidden.includes(friend.suggestion));
    assert.equal(g.lifeline('audience'),null);
    assert.equal(g.lifeline('friend'),null);
    winQuestion(g); g.next();
    assert.equal(g.hints.length,0);
    assert.equal(g.used.audience,true);
    assert.equal(g.used.friend,true);
  }
  const uncertain = game(() => 0.999);
  assert.notEqual(uncertain.lifeline('friend').suggestion, uncertain.question.correct);
});

test('new games reset lifelines and avoid seen questions when alternatives exist', () => {
  const first = game(() => 0);
  first.lifeline('fifty');
  const next = new Game(data.banks, () => 0, first.questions.map(q => q.id));
  next.questions.forEach((q,i) => assert.notEqual(q.id,first.questions[i].id));
  assert.deepEqual(next.used,{fifty:false,audience:false,friend:false});
  const tinyBanks = Object.fromEntries(first.questions.map((q,i) => [i+1,[q]]));
  assert.equal(new Game(tinyBanks, () => 0, first.questions.map(q=>q.id)).questions.length,15);
  assert.throws(() => new Game({}), /Missing questions/);
});
