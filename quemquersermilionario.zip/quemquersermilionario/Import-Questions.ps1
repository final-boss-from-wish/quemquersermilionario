param(
    [string]$SourceDirectory = (Join-Path $env:USERPROFILE 'Downloads'),
    [switch]$OpenGame
)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$banks = [ordered]@{}
$report = @()
$total = 0
$normalized = 0
$skipped = @()
foreach ($level in 1..15) {
    $name = "MillionaireDB_ WWTBAM Question Database - Q$level.csv"
    $source = Join-Path $SourceDirectory $name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        $source = Join-Path (Join-Path $root 'data') $name
    }
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing Q$level database: $name" }
    $rows = @(Import-Csv -LiteralPath $source -Encoding UTF8 -WarningAction SilentlyContinue)
    if ($rows.Count -eq 0) { throw "Q$level database is empty." }
    foreach ($column in @('Question','A','B','C','D','Correct')) {
        if ($rows[0].PSObject.Properties.Name -cnotcontains $column) { throw "Q$level is missing column $column." }
    }
    $questions = @()
    $line = 1
    foreach ($row in $rows) {
        $line++
        $key = ([string]$row.Correct).Trim().ToUpperInvariant()
        # The supplied data has three visually identical Cyrillic C keys.
        if ($key -ceq [string][char]0x0421) { $key = 'C'; $normalized++ }
        $options = @($row.A, $row.B, $row.C, $row.D) | ForEach-Object { ([string]$_).Trim() }
        if ([string]::IsNullOrWhiteSpace($row.Question) -or @($options | Where-Object { [string]::IsNullOrWhiteSpace($_) }).Count -gt 0 -or $key -cnotmatch '^[ABCD]$') {
            $skipped += [ordered]@{ level=$level; record=$line; question=$row.Question; reason='Missing question/choice or invalid correct-answer key' }
            continue
        }
        $questions += [ordered]@{ id="${level}:$line"; level=$level; text=$row.Question.Trim(); options=@($options); correct=('ABCD'.IndexOf($key)); source=([string]$row.'Question Source').Trim(); contributor=([string]$row.Contributor).Trim() }
    }
    if ($questions.Count -eq 0) { throw "Q$level has no valid questions." }
    $banks["$level"] = @($questions)
    $total += $questions.Count
    $report += [ordered]@{ level=$level; count=$questions.Count; source=$source }
}
$meta = [ordered]@{ total=$total; normalizedKeys=$normalized; skipped=@($skipped); levels=@($report); importedAt=(Get-Date).ToString('o') }
$payload = [ordered]@{ meta=$meta; banks=$banks } | ConvertTo-Json -Depth 8 -Compress
$utf8 = New-Object System.Text.UTF8Encoding($false)
$target = Join-Path $root 'questions.js'
[IO.File]::WriteAllText("$target.tmp", "window.MILLIONAIRE_DATA = $payload;", $utf8)
Move-Item -LiteralPath "$target.tmp" -Destination $target -Force
[IO.File]::WriteAllText((Join-Path $root 'import-report.json'), ($meta | ConvertTo-Json -Depth 6), $utf8)
Write-Host "Ready: $total questions across all 15 levels. Normalized $normalized answer keys; skipped $($skipped.Count) incomplete records."
if ($OpenGame) { Start-Process -FilePath (Join-Path $root 'index.html') }
