/* All questions are in memory; gameplay makes no network requests. */
'use strict';
(() => {
  const $ = id => document.getElementById(id);
  const money = value => '$' + value.toLocaleString('en-US');
  const data = window.MILLIONAIRE_DATA;
  const { Game, PRIZES, LETTERS } = window.Millionaire;
  let game;
  let previousIds = [];
  let seenThisSession = [];
  try { const saved = JSON.parse(localStorage.getItem('millionaire-seen') || '[]'); if (Array.isArray(saved)) previousIds = saved.filter(x => typeof x === 'string').slice(-3000); } catch (_) { /* Local storage is optional. */ }
  function rememberQuestion() {
    const id = game.question.id;
    if (!seenThisSession.includes(id)) seenThisSession.push(id);
    try { localStorage.setItem('millionaire-seen', JSON.stringify([...new Set([...previousIds, ...seenThisSession])].slice(-3000))); } catch (_) { /* File-mode storage can be disabled. */ }
  }
  function start() {
    game = new Game(data.banks, Math.random, [...previousIds, ...seenThisSession]);
    $('welcome').hidden = true;
    $('game-screen').hidden = false;
    rememberQuestion();
    render();
    $('question').focus();
  }
  function make(tag, className, text) {
    const element = document.createElement(tag);
    element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }
  function render() {
    const q = game.question;
    const active = game.phase === 'question';
    const ended = ['won', 'lost', 'walked'].includes(game.phase);
    const revealed = !active;
    $('round-label').textContent = `QUESTION ${game.index + 1} OF 15`;
    $('source-label').textContent = `DATABASE Q${q.level}`;
    $('playing-for').textContent = money(PRIZES[game.index]);
    $('guaranteed').textContent = money(game.guaranteed);
    $('question').textContent = q.text;
    $('answers').replaceChildren();
    q.options.forEach((option, index) => {
      const button = make('button', 'answer');
      button.classList.toggle('selected', active && game.selected === index);
      button.classList.toggle('eliminated', game.hidden.includes(index));
      button.classList.toggle('correct', revealed && index === q.correct);
      button.classList.toggle('wrong', game.phase === 'lost' && index === game.selected);
      button.disabled = !active || game.hidden.includes(index);
      button.setAttribute('aria-pressed', String(game.selected === index));
      let label = `${LETTERS[index]}: ${option}`;
      if (revealed && index === q.correct) label += ' — correct answer';
      else if (game.phase === 'lost' && index === game.selected) label += ' — incorrect answer';
      button.setAttribute('aria-label', label);
      button.append(make('span', 'letter', LETTERS[index]), make('span', '', option));
      if (revealed && index === q.correct) button.append(make('span', '', '✓'));
      if (game.phase === 'lost' && index === game.selected) button.append(make('span', '', '✕'));
      button.addEventListener('click', () => { game.select(index); render(); $('final-answer').focus(); });
      $('answers').append(button);
    });
    for (const type of ['fifty', 'audience', 'friend']) {
      $(type).disabled = !active || game.used[type];
      $(type).classList.toggle('used', game.used[type]);
      $(type).setAttribute('aria-label', ({fifty:'50:50', audience:'Ask the audience (simulated)', friend:'Phone a friend (simulated)'})[type] + (game.used[type] ? ' — used' : ''));
    }
    $('hints').replaceChildren();
    for (const hint of game.hints) {
      const panel = make('div', 'hint');
      panel.append(make('h3', 'hint-title', hint.type === 'friend' ? 'PHONE A FRIEND · SIMULATED, MAY BE WRONG' : 'AUDIENCE POLL · SIMULATED, MAY BE WRONG'));
      if (hint.type === 'friend') panel.append(make('p', '', hint.text));
      else {
        const chart = make('div', 'poll');
        hint.votes.forEach((votes, i) => {
          const item = make('div', 'poll-item');
          const label = make('div', 'poll-label');
          label.append(make('span', '', LETTERS[i]), make('span', '', `${votes}%`));
          const track = make('div', 'poll-track');
          const fill = make('div', 'poll-fill');
          fill.style.width = `${votes}%`;
          track.append(fill); item.append(label, track); chart.append(item);
        });
        panel.append(chart);
      }
      $('hints').append(panel);
    }
    const feedback = $('feedback');
    feedback.className = 'feedback';
    if (active) feedback.textContent = game.selected === null ? 'Choose an answer when you’re ready.' : `${LETTERS[game.selected]} selected. Is that your final answer?`;
    if (game.phase === 'correct') {
      feedback.classList.add('good');
      feedback.textContent = `Correct! You have ${money(game.earned)}.${[4, 9].includes(game.index) ? ' Safety net secured.' : ''}`;
    }
    if (ended) {
      feedback.classList.add('result', game.phase === 'lost' ? 'bad' : 'good');
      if (game.phase === 'won') feedback.textContent = 'You’re a millionaire! 15 correct answers. You won $1,000,000.';
      if (game.phase === 'lost') feedback.textContent = `The correct answer was ${LETTERS[q.correct]}: ${q.options[q.correct]}. You leave with ${money(game.payout)}.`;
      if (game.phase === 'walked') feedback.textContent = `You walked away with ${money(game.payout)}. The answer was ${LETTERS[q.correct]}: ${q.options[q.correct]}.`;
    }
    $('walk').hidden = ended;
    $('walk').textContent = `Walk away · ${money(game.earned)}`;
    $('final-answer').hidden = !active;
    $('final-answer').disabled = game.selected === null;
    $('next').hidden = game.phase !== 'correct';
    $('again').hidden = !ended;
    $('ladder').replaceChildren();
    [...PRIZES].reverse().forEach((prize, reverseIndex) => {
      const index = 14 - reverseIndex;
      const passed = index < game.index || (index === game.index && ['correct', 'won'].includes(game.phase));
      const safe = [4, 9, 14].includes(index);
      const item = make('li', `${safe ? 'safety ' : ''}${index === game.index ? 'current ' : ''}${passed ? 'passed' : ''}`);
      if (index === game.index) item.setAttribute('aria-current', 'step');
      item.value = index + 1;
      item.append(make('span', 'number', index + 1), make('span', 'amount', money(prize)), make('span', 'marker', passed ? '✓' : safe ? '◆' : ''));
      $('ladder').append(item);
    });
  }
  function confirm() { if (game.confirm()) { render(); (game.phase === 'correct' ? $('next') : $('again')).focus(); } }
  function next() { if (game.next()) { rememberQuestion(); render(); $('question').focus(); } }
  $('start').addEventListener('click', start);
  $('again').addEventListener('click', start);
  $('final-answer').addEventListener('click', confirm);
  $('next').addEventListener('click', next);
  for (const type of ['fifty', 'audience', 'friend']) $(type).addEventListener('click', () => { game.lifeline(type); render(); });
  $('walk').addEventListener('click', () => { $('walk-amount').textContent = money(game.earned); $('walk-dialog').showModal(); });
  $('confirm-walk').addEventListener('click', () => { game.walkAway(); $('walk-dialog').close(); render(); $('again').focus(); });
  $('rules-button').addEventListener('click', () => $('rules-dialog').showModal());
  $('credits-button').addEventListener('click', () => $('credits-dialog').showModal());
  document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => button.closest('dialog').close()));
  document.addEventListener('keydown', event => {
    if (!game || event.repeat || event.ctrlKey || event.metaKey || event.altKey || document.querySelector('dialog[open]')) return;
    const key = event.key.toUpperCase();
    const index = LETTERS.indexOf(key);
    if (key.length === 1 && ((index >= 0) || /^[1-4]$/.test(key)) && game.phase === 'question') {
      event.preventDefault();
      game.select(index >= 0 ? index : Number(key) - 1);
      render();
    } else if (key === 'ENTER') {
      // Preserve native Enter activation on buttons (including modal controls).
      if (document.activeElement?.tagName === 'BUTTON') return;
      event.preventDefault();
      if (game.phase === 'question') confirm();
      else if (game.phase === 'correct') next();
    }
  });
  if (!data || !data.banks || !PRIZES.every((_, i) => Array.isArray(data.banks[i + 1]) && data.banks[i + 1].length)) {
    $('start').disabled = true;
    $('load-status').textContent = 'Question data is missing or incomplete. Run Play.cmd to reload your CSV databases.';
    document.querySelector('.offline').textContent = 'Database unavailable';
  } else {
    $('bank-count').textContent = data.meta.total.toLocaleString('en-US');
    $('database-details').textContent = `${data.meta.total.toLocaleString('en-US')} playable questions. ${data.meta.normalizedKeys} Cyrillic C answer keys normalized; ${data.meta.skipped.length} incomplete question excluded. Loaded once at startup for instant play.`;
  }
})();
