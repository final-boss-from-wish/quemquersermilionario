@echo off
setlocal
cd /d "%~dp0"
echo Loading your Millionaire question databases...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Import-Questions.ps1" -OpenGame
if errorlevel 1 (
  echo.
  echo Could not load the databases. See the message above.
  echo You can open index.html to play the last successfully imported database.
  pause
)
