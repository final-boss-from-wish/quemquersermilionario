# Millionaire — local PC game

Double-click **Play.cmd**. It reads all 15 CSV databases, then opens the game in your default browser. Windows PowerShell is built into Windows; no installation, account, internet connection, Python or Node.js is required to play.

For the fastest launch, open **index.html** directly. It uses the last imported question bank. Keep this whole folder together.

## Your databases

The launcher looks for `MillionaireDB_ WWTBAM Question Database - Q1.csv` through `Q15.csv` in your Windows user Downloads folder. If a file is missing, it uses the corresponding copy in `data/`. The supplied original files are never modified. To use updated files, replace the CSVs in Downloads and launch again. To prefer another source folder, run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Import-Questions.ps1 -SourceDirectory 'C:\Your\DatabaseFolder' -OpenGame
```

Every run selects one random question from each matching level: Q1 for question 1, Q2 for question 2, and so on to Q15. Previously shown questions are avoided while alternatives remain, using browser local storage when available. The question bank loads once; there are no per-question requests, network services, or forced delays.

Import validation checks every row for a question, four nonempty answers and an A–D answer key. Three Cyrillic `С` keys in the supplied data are normalized to Latin `C`. One incomplete Q15 question is excluded. `import-report.json` lists counts, source files and rejected records. Question wording and answer correctness otherwise follow the supplied database; historical or factual errors may remain. Import failures leave the last successfully generated `questions.js` available.

## Playing

- Select A–D (or press A–D / 1–4), then click **Final answer**. Enter also confirms/continues when a relevant control or the game itself has focus.
- The classic prize ladder runs from $100 to $1,000,000 across 15 questions. Correct Q5 and Q10 answers secure $1,000 and $32,000. An incorrect answer ends the run at the last safety net; failing Q5 itself pays $0, and failing Q10 itself pays $1,000.
- Walk away before locking an answer to retain your current winnings. Walking away after a correct answer is also allowed.
- Each lifeline is available once per game. 50:50 removes two incorrect choices. Audience and friend suggestions are instant **simulations**, may be wrong, and get less reliable at higher levels. Existing advice is retained if you later use 50:50.
- No countdown or artificial suspense. Click **Next question** after each correct answer. All prizes are fictional.

Rules reference: https://wwbm.com/rules (classic 15-question dollar ladder and lifelines).

## Credits

MillionaireDB compiled by **MrMartley64**. Community editors listed in INTRO: Quochieu0211, Huong, Jordan, Biz150, AdmiralSven, Arty the Biocosmic Boy. The supplied introduction credits Sony Pictures Television and the 2020 PC game released by Microids. Original INTRO.csv is retained in `data/`. This is an unofficial local fan game.

## Developer checks

With Node.js installed, run `node --test tests/engine.test.cjs`. There are no package dependencies or build step. `engine.js` holds game rules, `app.js` connects the UI, and `Import-Questions.ps1` validates and generates the offline question bank. Modern Edge, Chrome and Firefox support the browser features used here.
