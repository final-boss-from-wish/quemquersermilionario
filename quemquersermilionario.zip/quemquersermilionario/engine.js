(function (root) {
  'use strict';
  const PRIZES = Object.freeze([100, 200, 300, 500, 1000, 2000, 4000, 8000, 16000, 32000, 64000, 125000, 250000, 500000, 1000000]);
  const LETTERS = 'ABCD';
  function pick(items, rng) { return items[Math.floor(rng() * items.length)]; }
  class Game {
    constructor(banks, rng = Math.random, previousIds = []) {
      this.rng = rng;
      this.questions = PRIZES.map((_, index) => {
        const bank = banks[index + 1];
        if (!Array.isArray(bank) || !bank.length) throw new Error(`Missing questions for Q${index + 1}.`);
        const fresh = bank.filter(q => !previousIds.includes(q.id));
        return pick(fresh.length ? fresh : bank, rng);
      });
      this.index = 0;
      this.earned = 0;
      this.guaranteed = 0;
      this.payout = 0;
      this.phase = 'question';
      this.selected = null;
      this.hidden = [];
      this.used = { fifty: false, audience: false, friend: false };
      this.hints = [];
    }
    get question() { return this.questions[this.index]; }
    select(answer) {
      if (this.phase !== 'question' || !Number.isInteger(answer) || answer < 0 || answer > 3 || this.hidden.includes(answer)) return false;
      this.selected = answer;
      return true;
    }
    confirm() {
      if (this.phase !== 'question' || this.selected === null) return false;
      if (this.selected !== this.question.correct) {
        this.phase = 'lost';
        this.payout = this.guaranteed;
        return true;
      }
      this.earned = PRIZES[this.index];
      if (this.index === 4 || this.index === 9 || this.index === 14) this.guaranteed = this.earned;
      this.phase = this.index === 14 ? 'won' : 'correct';
      if (this.phase === 'won') this.payout = this.earned;
      return true;
    }
    next() {
      if (this.phase !== 'correct') return false;
      this.index++;
      this.phase = 'question';
      this.selected = null;
      this.hidden = [];
      this.hints = [];
      return true;
    }
    walkAway() {
      if (!['question', 'correct'].includes(this.phase)) return false;
      this.payout = this.earned;
      this.phase = 'walked';
      return true;
    }
    lifeline(type) {
      if (this.phase !== 'question' || !Object.hasOwn(this.used, type) || this.used[type]) return null;
      this.used[type] = true;
      const correct = this.question.correct;
      if (type === 'fifty') {
        const wrong = [0, 1, 2, 3].filter(i => i !== correct);
        const keep = pick(wrong, this.rng);
        this.hidden = wrong.filter(i => i !== keep);
        if (this.hidden.includes(this.selected)) this.selected = null;
        return { type };
      }
      const available = [0, 1, 2, 3].filter(i => !this.hidden.includes(i));
      // Simulated helpers become less reliable as difficulty rises.
      const accuracy = type === 'audience' ? 0.95 - this.index * 0.025 : 0.90 - this.index * 0.03;
      const suggestion = this.rng() < accuracy ? correct : pick(available.filter(i => i !== correct), this.rng);
      let hint;
      if (type === 'friend') {
        hint = { type, suggestion, text: `I'd go with ${LETTERS[suggestion]}: ${this.question.options[suggestion]}. ${this.index < 5 ? 'That sounds familiar!' : "I'm not completely sure, though."}` };
      } else {
        const votes = [0, 0, 0, 0];
        const support = 0.52 + this.rng() * 0.3;
        const others = available.filter(i => i !== suggestion);
        for (let voter = 0; voter < 100; voter++) votes[this.rng() < support ? suggestion : pick(others, this.rng)]++;
        hint = { type, votes };
      }
      this.hints.push(hint);
      return hint;
    }
  }
  const api = { Game, PRIZES, LETTERS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Millionaire = api;
})(typeof window === 'undefined' ? globalThis : window);
